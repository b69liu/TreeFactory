const TreeToken = artifacts.require("TreeToken");

module.exports = function (deployer) {
  deployer.deploy(TreeToken);
};
