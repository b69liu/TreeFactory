const TreeToken = artifacts.require("TreeToken");
const Receiver = artifacts.require("Receiver");
const truffleAssert = require('truffle-assertions');

contract("TreeToken", function(accounts){
    let instance;
    const name1 = "firstTree";
    const latitute1 = "39.774769";
    const longitute1 = "-243.918922";
    const name2 = "secondTree";
    const latitute2 = "43.909766";
    const longitute2 = "-79.989433";
    let tree1 = null;
    let tree2 = null;
    
    before(async () =>{
        instance = await TreeToken.deployed();
    });

    it("should have the contract owner address", async ()=>{
        const owner = await instance.owner();
        assert.equal(owner, accounts[0]);
    });

    it("should non-contract-owner planting tree be reverted", async ()=>{
        const randomPerson = accounts[5];
        await truffleAssert.reverts(
            instance.plant_tree(randomPerson,name1, latitute1, longitute1, {from: randomPerson}),
            "Only owner can operate."
        );
    });
    
    it("should planting tree for account1 triggle event Plant", async ()=>{
        const currentPlanter = accounts[1];
        const plantResult = await instance.plant_tree(currentPlanter,name1, latitute1, longitute1);
        tree1 = await instance.trees(0);      
        truffleAssert.eventEmitted(plantResult, 'Plant', (ev) => {
            return ev.tokenId.toString() === tree1.id.toString() && ev.planter === currentPlanter && ev.tokenIndex==0;
        });    
    });

    it("should planting tree increment balanceOf by 1", async ()=>{
        const currentPlanter = accounts[1];
        const currentPlanterBalance = await instance.balanceOf(currentPlanter);
        assert.equal(currentPlanterBalance,1);
    });

    it("should planting tree add a token to ownerOf for the planter", async ()=>{
        const currentPlanter = accounts[1];
        const ownerOfTree1 = await instance.ownerOf(tree1.id);
        assert.equal(ownerOfTree1,currentPlanter);
    });

    it("should safeTransferFrom revert if not approved", async ()=>{
        const isApproved = await instance.getApproved(tree1.id);
        assert.equal(isApproved,false);
        await truffleAssert.reverts(
            instance.safeTransferFrom(accounts[1], accounts[0], tree1.id),
            "ERC721: transfer caller is not owner nor approved."
        );
    });

    it("should approve() set an account approved", async ()=>{
        await instance.approve(accounts[0], tree1.id,{from: accounts[1]});
        const isApproved = await instance.getApproved(tree1.id);
        assert.equal(isApproved,accounts[0]);
    });

    it("should safeTransferFrom transfer owner", async ()=>{
        await instance.safeTransferFrom(accounts[1], accounts[2], tree1.id);
        const newOwner = await instance.ownerOf(tree1.id);
        assert.equal(newOwner, accounts[2]);
    });

    it("should safeTransferFrom(data) transfer ownership with data to receiver with IERC721Receiver interface", async ()=>{
        const testData = "0x000001111111";
        const receiverContract = await Receiver.new(instance.address);
        const receiverContractAddress = receiverContract.address;
        await instance.plant_tree(accounts[0],name2, latitute2, longitute2);
        tree2 = await instance.trees(1);
        await instance.safeTransferFrom(accounts[0], receiverContractAddress, tree2.id, testData);
        let receivedOperator = receiverContract.operator_();
        let receivedFrom = receiverContract.from_();
        let receivedData = receiverContract.data_();
        let newOwner =  instance.ownerOf(tree2.id);
        [receivedOperator, receivedFrom, receivedData, newOwner] = await Promise.all([receivedOperator, receivedFrom, receivedData, newOwner]);
        assert.equal(receivedOperator, accounts[0]);
        assert.equal(receivedFrom, accounts[0]);
        assert.equal(receivedData, testData);
        assert.equal(newOwner, receiverContractAddress);
        // self-destruct the testing contract and transfer the tree2 back to account0
        await receiverContract.burn();
        const finalOwner = await instance.ownerOf(tree2.id);
        assert.equal(finalOwner,accounts[0]);
    });

    it("should transfromFrom transfer the ownership", async ()=>{
        await instance.transferFrom(accounts[2], accounts[0], tree1.id,{from: accounts[2]});
        const newOwner = await instance.ownerOf(tree1.id);
        assert.equal(newOwner,accounts[0]);
    });

    it("should setApproveForAll give one's all approval", async ()=>{
        await instance.setApprovalForAll(accounts[3],true);
        await Promise.all([
            instance.transferFrom(accounts[0],accounts[3],tree1.id,{from: accounts[3]}),
            instance.transferFrom(accounts[0],accounts[3],tree2.id,{from: accounts[3]})
        ])
        const [tree1NewOwner, tree2NewOwner] = await Promise.all([
            instance.ownerOf(tree1.id),
            instance.ownerOf(tree2.id)
        ]);
        assert.equal(tree1NewOwner, accounts[3]);
        assert.equal(tree2NewOwner, accounts[3]);
    });

    it("should getApproved revert if token no exist", async ()=>{
        await truffleAssert.reverts(
            instance.getApproved(99,{from: accounts[3]}),
            "revert ERC721: approved query for nonexistent token"
        );
    });

    it("should isApprovedForAll return true after setApproveForAll", async ()=>{
        await instance.setApprovalForAll(accounts[0],true,{from: accounts[3]});
        const result = await instance.isApprovedForAll(accounts[3],accounts[0]);
        assert.ok(result);
    });

    it("should Transfer event be triggered when transfering", async ()=>{
        const result = await instance.transferFrom(accounts[3], accounts[2],tree1.id);
        truffleAssert.eventEmitted(result, 'Transfer', (ev) => {
            return ev.from === accounts[3] && ev.to === accounts[2] && ev.tokenId.toString() == tree1.id.toString();
        });
    });

    it("should Approval event be triggered when approve()", async ()=>{
        const result = await instance.approve(accounts[4],tree1.id,{from: accounts[2]});
        truffleAssert.eventEmitted(result, 'Approval', (ev) => {
            return ev.owner === accounts[2] && ev.approved === accounts[4] && ev.tokenId.toString() === tree1.id.toString();
        });
    });

    it("should ApprovalForAll event be triggered when setApproveForAll()", async ()=>{
        const result = await instance.setApprovalForAll(accounts[0], true, {from: accounts[4]});
        truffleAssert.eventEmitted(result, 'ApprovalForAll', (ev) => {
            return ev.owner === accounts[4] && ev.operator === accounts[0] && ev.approved;
        });
    });

    it("should support interface ERC165 and ERC721", async ()=>{
        // check ERC165 interface
        const ERC165Result = await instance.supportsInterface("0x01ffc9a7");
        assert.ok(ERC165Result);
        // check ERC721 interface
        const IERC721Result = await instance.supportsInterface("0x80ac58cd");
        assert.ok(IERC721Result);
    })




})